#include <iostream>
#include <cstdlib>
#include <unistd.h>
#include "test.h"
using namespace std;
void cleanup() {
	cout << "cleaning up and exitting" << endl;
	return;
}

